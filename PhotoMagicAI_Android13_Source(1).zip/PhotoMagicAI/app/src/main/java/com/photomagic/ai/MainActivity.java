package com.photomagic.ai;

import android.app.Activity;
import android.os.Bundle;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private ImageView preview;
    private Bitmap original, edited;
    private TextView status;
    private ActivityResultLauncher<String> picker;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(23,21,42));
        getWindow().setNavigationBarColor(Color.rgb(23,21,42));
        picker = registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
            if (uri != null) loadImage(uri);
        });
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(17,16,32));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(22), dp(18), dp(24));
        scroll.addView(root);

        TextView brand = new TextView(this);
        brand.setText("✦  PhotoMagic AI");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(25);
        brand.setTypeface(null, 1);
        root.addView(brand);

        TextView subtitle = new TextView(this);
        subtitle.setText("Make every photo look its best");
        subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14);
        subtitle.setPadding(0, dp(5), 0, dp(18));
        root.addView(subtitle);

        Button choose = button("＋  Choose photo");
        choose.setOnClickListener(v -> picker.launch("image/*"));
        root.addView(choose);

        preview = new ImageView(this);
        preview.setBackgroundColor(Color.rgb(37,34,57));
        preview.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1, dp(330));
        imageParams.setMargins(0, dp(16), 0, dp(14));
        root.addView(preview, imageParams);

        status = new TextView(this);
        status.setText("Choose a photo to start editing.");
        status.setTextColor(Color.LTGRAY);
        status.setTextSize(13);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, dp(4), 0, dp(12));
        root.addView(status);

        TextView tools = new TextView(this);
        tools.setText("EDITING TOOLS");
        tools.setTextColor(Color.WHITE);
        tools.setTextSize(13);
        tools.setTypeface(null, 1);
        tools.setPadding(0, dp(8), 0, dp(10));
        root.addView(tools);

        addTool(root, "✨  Auto Correct", "Adjust brightness, contrast and colour", this::autoCorrect);
        addTool(root, "👥  Auto Remove People", "AI background-person removal", () -> comingSoon("Automatic people removal needs an integrated inpainting AI model."));
        addTool(root, "↔  Body Slim", "Natural body shaping; preserve face", () -> comingSoon("Body shaping needs a person/pose-aware body-warping model."));
        addTool(root, "🌄  Background Editor", "Blur or replace the background", () -> comingSoon("Background editing needs a segmentation model."));
        addTool(root, "↶  Undo", "Restore the original photo", this::undo);

        Button save = button("Save HD photo");
        save.setOnClickListener(v -> saveImage());
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(-1, dp(52));
        saveParams.setMargins(0, dp(16), 0, 0);
        root.addView(save, saveParams);

        setContentView(scroll);
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(15);
        return b;
    }

    private void addTool(LinearLayout root, String title, String desc, Runnable action) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(10), dp(14), dp(10));
        card.setBackgroundColor(Color.rgb(35,32,55));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, dp(5), 0, dp(5));
        root.addView(card, p);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        t.setTypeface(null, 1);
        card.addView(t);

        TextView d = new TextView(this);
        d.setText(desc);
        d.setTextColor(Color.LTGRAY);
        d.setTextSize(12);
        card.addView(d);

        card.setOnClickListener(v -> {
            if (original == null) { toast("Choose a photo first."); return; }
            action.run();
        });
    }

    private void loadImage(Uri uri) {
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            original = BitmapFactory.decodeStream(in);
            edited = original.copy(Bitmap.Config.ARGB_8888, true);
            preview.setImageBitmap(edited);
            status.setText("Photo loaded • " + original.getWidth() + " × " + original.getHeight());
        } catch (Exception e) { toast("Could not open this photo."); }
    }

    // Basic on-device enhancement; this is not generative AI.
    private void autoCorrect() {
        if (original == null) return;
        Bitmap src = original;
        Bitmap out = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
        int w = src.getWidth(), h = src.getHeight();
        int[] pixels = new int[w*h];
        src.getPixels(pixels, 0, w, 0, 0, w, h);
        for (int i=0; i<pixels.length; i++) {
            int c = pixels[i];
            int r = Color.red(c), g = Color.green(c), b = Color.blue(c);
            r = clamp((int)((r - 128) * 1.10 + 134));
            g = clamp((int)((g - 128) * 1.10 + 134));
            b = clamp((int)((b - 128) * 1.10 + 134));
            pixels[i] = Color.argb(Color.alpha(c), r, g, b);
        }
        out.setPixels(pixels, 0, w, 0, 0, w, h);
        edited = out;
        preview.setImageBitmap(edited);
        status.setText("Auto-correct applied • Preview your result");
    }

    private int clamp(int v) { return Math.max(0, Math.min(255, v)); }

    private void undo() {
        if (original != null) {
            edited = original.copy(Bitmap.Config.ARGB_8888, true);
            preview.setImageBitmap(edited);
            status.setText("Original photo restored.");
        }
    }

    private void saveImage() {
        if (edited == null) { toast("Choose a photo first."); return; }
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, "PhotoMagic_" + System.currentTimeMillis() + ".jpg");
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/PhotoMagicAI");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new Exception("Save failed");
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                edited.compress(Bitmap.CompressFormat.JPEG, 95, out);
            }
            toast("Saved to Pictures/PhotoMagicAI");
        } catch (Exception e) { toast("Could not save photo."); }
    }

    private void comingSoon(String message) {
        new android.app.AlertDialog.Builder(this)
            .setTitle("AI model integration required")
            .setMessage(message + "\n\nThe editor interface is ready, but this AI operation is not active yet.")
            .setPositiveButton("OK", null).show();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
